Controller Type: PI + Feedforward
Ki: 10.5
Kp: 1.0
