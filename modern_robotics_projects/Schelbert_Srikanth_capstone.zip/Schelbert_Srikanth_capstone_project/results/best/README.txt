Controller Type: PI + Feedforward
Ki: 0.5
Kp: 1.0
